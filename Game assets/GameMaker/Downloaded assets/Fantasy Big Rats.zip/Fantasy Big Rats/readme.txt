Thank you for downloading The Fantasy Big Rat Mob!

This asset pack can be used in both free and commercial projects. You may modify the assets. You may not repackage, redistribute or resell the assets even if modified. You do not need to Credit me, but it is always appreciated. 

rat is 48x18

for pngs:
row 1 is Base Frame
row 2 is Idle Animation
row 3 is Movement Animation
row 4 is Attack Animation
row 5 is Dead Frame